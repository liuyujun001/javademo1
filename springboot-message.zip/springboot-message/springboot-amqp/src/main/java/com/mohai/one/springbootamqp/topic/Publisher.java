package com.mohai.one.springbootamqp.topic;

/**
 * @Auther: moerhai@qq.com
 * @Date: 2020/11/8 00:14
 */
public class Publisher {

    public static void main(String[] args) {

    }

}
