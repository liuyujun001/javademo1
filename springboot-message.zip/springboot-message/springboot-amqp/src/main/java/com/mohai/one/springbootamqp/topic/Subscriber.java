package com.mohai.one.springbootamqp.topic;

/**
 * @Auther: moerhai@qq.com
 * @Date: 2020/11/8 00:14
 */
public class Subscriber {

    public static void main(String[] args) {

    }

}
