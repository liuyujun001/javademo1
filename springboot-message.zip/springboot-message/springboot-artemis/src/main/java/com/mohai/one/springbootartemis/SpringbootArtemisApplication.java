package com.mohai.one.springbootartemis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootArtemisApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootArtemisApplication.class, args);
	}

}
