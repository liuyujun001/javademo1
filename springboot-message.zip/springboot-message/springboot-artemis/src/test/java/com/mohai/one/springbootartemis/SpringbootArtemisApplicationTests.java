package com.mohai.one.springbootartemis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootArtemisApplicationTests {

	@Test
	void contextLoads() {
	}

}
