package com.mohai.one.rocketmqconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RocketmqConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
