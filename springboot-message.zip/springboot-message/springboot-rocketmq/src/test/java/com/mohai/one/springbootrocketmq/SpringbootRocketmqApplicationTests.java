package com.mohai.one.springbootrocketmq;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootRocketmqApplicationTests {

	@Test
	void contextLoads() {
	}

}
