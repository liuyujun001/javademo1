package com.mohai.one.rocketmqproduce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RocketmqProduceApplicationTests {

	@Test
	void contextLoads() {
	}

}
