package com.mohai.one.app.core.user.dao;

import com.mohai.one.app.core.user.domain.AdminPermission;

import java.util.List;

/**
 * @Auther: moerhai@qq.com
 * @Date: 2020/12/25 01:12
 */
public interface AdminUrlPathMapper {



}
