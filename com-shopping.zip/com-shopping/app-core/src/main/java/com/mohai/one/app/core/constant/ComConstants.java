package com.mohai.one.app.core.constant;

/**
 * @Auther: moerhai@qq.com
 * @Date: 2020/12/4 00:58
 */
public interface ComConstants {

    // 正常
    String STATUS_0 = "0";
    // 冻结
    String STATUS_1 = "1";
    // 删除
    String STATUS_2 = "2";

    // 是
    String STATUS_Y = "Y";
    // 否
    String STATUS_N = "N";

}